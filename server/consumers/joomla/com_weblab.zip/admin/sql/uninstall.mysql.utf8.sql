DROP TABLE IF EXISTS `#__weblab`; 

DROP TABLE IF EXISTS `#__weblab_config`;